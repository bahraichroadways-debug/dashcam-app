// settings-tab.js — settings form render + save ONLY.

const DEFAULT_SETTINGS = {
  recordingRetentionDays: 3,
  lowBatteryThreshold: 15,
  offlineThresholdMinutes: 2
};

function watchSettings(db, onUpdate) {
  return db.collection('settings').doc('fleet').onSnapshot((snap) => {
    onUpdate({ ...DEFAULT_SETTINGS, ...(snap.data() || {}) });
  });
}

function renderSettingsTab(containerEl, settings, onSave) {
  containerEl.innerHTML = `
    <div class="settings-form glass">
      <label>Recording retention (days)<input id="setRetention" type="number" value="${settings.recordingRetentionDays}"></label>
      <label>Low battery alert (%)<input id="setBattery" type="number" value="${settings.lowBatteryThreshold}"></label>
      <label>Offline threshold (minutes)<input id="setOffline" type="number" value="${settings.offlineThresholdMinutes}"></label>
      <button id="saveSettingsBtn" class="add-btn">Save</button>
    </div>
  `;
  containerEl.querySelector('#saveSettingsBtn').addEventListener('click', () => {
    onSave({
      recordingRetentionDays: Number(containerEl.querySelector('#setRetention').value) || DEFAULT_SETTINGS.recordingRetentionDays,
      lowBatteryThreshold: Number(containerEl.querySelector('#setBattery').value) || DEFAULT_SETTINGS.lowBatteryThreshold,
      offlineThresholdMinutes: Number(containerEl.querySelector('#setOffline').value) || DEFAULT_SETTINGS.offlineThresholdMinutes
    });
  });
}

window.SettingsTab = { watchSettings, renderSettingsTab, DEFAULT_SETTINGS };
