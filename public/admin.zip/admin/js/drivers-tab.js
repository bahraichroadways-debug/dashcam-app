// drivers-tab.js — driver list render + add-driver form ONLY.

function watchDrivers(db, onUpdate) {
  return db.collection('drivers').onSnapshot((snap) => {
    onUpdate(snap.docs.map(d => ({ id: d.id, ...d.data() })));
  });
}

function renderDriversTab(containerEl, drivers, onAdd) {
  containerEl.innerHTML = `
    <div class="drivers-add glass">
      <input id="newDriverName" placeholder="Driver Name" />
      <input id="newDriverTruck" placeholder="Truck ID (e.g. TRUCK4)" />
      <button id="addDriverBtn" class="add-btn">Add</button>
    </div>
    <div id="driversList" class="drivers-list">
      ${drivers.length ? drivers.map(d => `
        <div class="driver-row glass">
          <span>${d.name || 'Unnamed'}</span>
          <span class="driver-truck">${d.truckId || '--'}</span>
        </div>`).join('') : '<div class="tab-placeholder glass">Koi driver add nahi hua abhi</div>'}
    </div>
  `;
  containerEl.querySelector('#addDriverBtn').addEventListener('click', () => {
    const name = containerEl.querySelector('#newDriverName').value.trim();
    const truckId = containerEl.querySelector('#newDriverTruck').value.trim();
    if (!name || !truckId) { window.showToast('Naam aur Truck ID dono chahiye', 'error'); return; }
    onAdd({ name, truckId });
  });
}

window.DriversTab = { watchDrivers, renderDriversTab };
