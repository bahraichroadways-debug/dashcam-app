// ==========================================
// FILE: public/driver/js/bg-keeper.js
// 24/7 BACKGROUND GPS KEEPER ENGINE (AUDIO-HARDWARE PULSE)
// ==========================================

(function() {
  // 🛡️ व्यूअर मोड में 100% निष्क्रिय (0% बैटरी/संसाधन उपयोग)
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('role') === 'viewer' || window.isViewerMode === true) {
    return;
  }

  let audioEl = null;
  let isKeeperActive = false;
  let lastGpsPulse = 0;

  // 1. शुद्ध मूक (100% Silent) 1-सेकंड की ऑडियो डेटा URI (शून्य नेटवर्क डेटा)
  const SILENT_WAV_BASE64 = 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';

  // 2. Android लॉक-स्क्रीन मीडिया नोटिफिकेशन रजिस्टर करना
  function setupMediaSession() {
    if ('mediaSession' in navigator) {
      const truck = localStorage.getItem('driver_vehicle_num') || 'ट्रक';
      navigator.mediaSession.metadata = new MediaMetadata({
        title: '🚛 Bahraich Roadways Live GPS',
        artist: `गाड़ी: ${truck} · लाइव ट्रैकिंग सक्रिय`,
        album: 'Bahraich Roadways Transport',
        artwork: [
          { src: 'https://cdn-icons-png.flaticon.com/512/2554/2554978.png', sizes: '512x512', type: 'image/png' }
        ]
      });

      // प्ले/पॉज़ से भी बैकग्राउंड जिंदा रहेगा
      navigator.mediaSession.setActionHandler('play', () => startKeeper());
      navigator.mediaSession.setActionHandler('pause', () => startKeeper());
    }
  }

  // 3. हार्डवेयर ऑडियो पल्स चालू करना (डूज़ मोड को बाईपास करने वाला इंजन)
  function startKeeper() {
    if (isKeeperActive) return;

    try {
      if (!audioEl) {
        audioEl = document.createElement('audio');
        audioEl.src = SILENT_WAV_BASE64;
        audioEl.loop = true;
        audioEl.volume = 0.01; // मूक आवाज़
        audioEl.setAttribute('playsinline', 'true');
        audioEl.setAttribute('webkit-playsinline', 'true');

        // ⚡ जब भी ऑडियो लूप करेगा (हार्डवेयर इवेंट), GPS को पल्स भेजेगा
        audioEl.addEventListener('timeupdate', () => {
          const now = Date.now();
          // हर 18-20 सेकंड में बैकग्राउंड GPS पिंग
          if (now - lastGpsPulse >= 18000) {
            lastGpsPulse = now;
            if (window.FleetGPS && typeof window.FleetGPS.fetchPosition === 'function') {
              window.FleetGPS.fetchPosition(() => {});
            }
          }
        });
      }

      const playPromise = audioEl.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
          isKeeperActive = true;
          setupMediaSession();
          console.log("🟢 Background GPS Keeper Engine Active (24/7 Shield ON)");
        }).catch(() => {
          // यूज़र जेस्चर का इंतज़ार करेगा
        });
      }
    } catch(e) {}
  }

  // 4. ड्राइवर के पहले स्क्रीन टच या क्लिक पर ऑटो-स्टार्ट (ब्राउज़र प्राइवेसी पास)
  const triggerEvents = ['click', 'touchstart', 'touchend'];
  function onFirstUserGesture() {
    startKeeper();
    triggerEvents.forEach(evt => document.removeEventListener(evt, onFirstUserGesture));
  }
  triggerEvents.forEach(evt => document.addEventListener(evt, onFirstUserGesture, { passive: true, once: true }));

  // 5. स्क्रीन लॉक होने पर या ऐप बैकग्राउंड में जाने पर तुरंत एक्टिव रखना
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      startKeeper();
    }
  });

  window.BGKeeper = {
    start: startKeeper,
    isActive: () => isKeeperActive
  };
})();