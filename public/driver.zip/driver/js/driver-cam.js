// =========================================================================
// FILE: public/driver/js/driver-cam.js
// ON-DEMAND DASHCAM ENGINE (0% IDLE BATTERY & SENSOR SLEEP)
// =========================================================================

async function initDriverCam(videoEl, truckId) {
  let facingMode = localStorage.getItem('driver_cam_facing') || 'environment';
  let torchOn = false;
  let nightMode = false;
  let stream = null;
  let broadcastTimer = null;

async function getStream(mode) {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        return await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: mode } },
          audio: false // 🎯 कैमरे को माइक से आज़ाद किया (0% माइक लॉक)
        });
      }
    } catch(e1) {
      try {
        return await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false // 🎯 फॉलबैक में भी नो माइक
        });
      } catch(e2) {
        return null;
      }
    }
  }

  // 🚀 कैमरे का हार्डवेयर चालू करना
  async function startCamera() {
    if (stream && stream.active) return stream;
    stream = await getStream(facingMode);
    if (videoEl && stream && stream.getVideoTracks().length > 0) {
      videoEl.srcObject = stream;
      startLiveFrameBroadcast();
    }
    return stream;
  }

  // 🛑 कैमरे का हार्डवेयर पूरी तरह बंद करना (फोन को ठंडा रखने के लिए)
  function stopCamera() {
    if (broadcastTimer) { clearInterval(broadcastTimer); broadcastTimer = null; }
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      stream = null;
    }
    if (videoEl) videoEl.srcObject = null;
  }

  // 📡 लाइव फ़्रेम ट्रांसमीटर (400ms)
  function startLiveFrameBroadcast() {
    if (broadcastTimer) clearInterval(broadcastTimer);

    const canvas = document.createElement('canvas');
    canvas.width = 360;
    canvas.height = 202;
    const ctx = canvas.getContext('2d');

    broadcastTimer = setInterval(() => {
      if (!videoEl || !videoEl.videoWidth || !truckId || !stream) return;

      try {
        ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
        const frameData = canvas.toDataURL('image/jpeg', 0.40);

        const db = (typeof firebase !== 'undefined' && firebase.firestore) ? firebase.firestore() : null;
        if (db) {
          db.collection('calls').doc(`truck_${truckId}`).set({
            live_frame: frameData,
            frame_ts: Date.now()
          }, { merge: true }).catch(() => {});
        }
      } catch(e) {}
    }, 400);
  }

  async function switchCamera() {
    facingMode = facingMode === 'environment' ? 'user' : 'environment';
    stopCamera();
    return await startCamera();
  }

  async function toggleTorch() {
    if (!stream) return false;
    const track = stream.getVideoTracks()[0];
    const caps = (track && track.getCapabilities) ? track.getCapabilities() : {};
    if (!caps.torch) return false;
    torchOn = !torchOn;
    await track.applyConstraints({ advanced: [{ torch: torchOn }] });
    return torchOn;
  }

  function toggleNightMode() {
    nightMode = !nightMode;
    if (videoEl) {
      videoEl.style.filter = nightMode ? 'brightness(1.5) contrast(1.2)' : 'none';
    }
    return nightMode;
  }

  return {
    startCamera,
    stopCamera,
    getStream: () => stream,
    getMicTrack: () => (stream ? stream.getAudioTracks()[0] : null),
    switchCamera, toggleTorch, toggleNightMode
  };
}

window.DriverCam = { initDriverCam };